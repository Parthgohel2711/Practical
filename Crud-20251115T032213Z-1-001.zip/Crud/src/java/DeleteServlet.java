import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@WebServlet("/DeleteServlet")
public class DeleteServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String idParam = request.getParameter("id");
        if (idParam == null || idParam.isEmpty()) {
            response.getWriter().println("<h3>No ID provided to delete.</h3>");
            return;
        }

        int id = Integer.parseInt(idParam);

        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        out.println("<!DOCTYPE html>");
        out.println("<html lang='en'>");
        out.println("<head>");
        out.println("<meta charset='UTF-8'>");
        out.println("<meta name='viewport' content='width=device-width, initial-scale=1'>");
        out.println("<title>Delete Confirmation</title>");

        // Bootstrap CSS
        out.println("<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css' rel='stylesheet'>");
        out.println("</head>");
        out.println("<body class='bg-light d-flex justify-content-center align-items-center vh-100'>");

        // Modal-like card for confirmation
        out.println("<div class='card shadow-lg p-4 text-center' style='max-width: 400px;'>");
        out.println("<h4 class='mb-3 text-danger'><i class='fa-solid fa-triangle-exclamation me-2'></i>Confirm Deletion</h4>");
        out.println("<p>Are you sure you want to delete this record (ID: " + id + ")?</p>");
        out.println("<div class='d-flex justify-content-center gap-3 mt-4'>");

        // Confirm form
        out.println("<form action='DeleteServlet' method='post'>");
        out.println("<input type='hidden' name='id' value='" + id + "'>");
        out.println("<button type='submit' class='btn btn-danger'><i class='fa-solid fa-trash me-1'></i>Delete</button>");
        out.println("</form>");

        // Cancel button
        out.println("<a href='ViewServlet' class='btn btn-secondary'><i class='fa-solid fa-xmark me-1'></i>Cancel</a>");

        out.println("</div>");
        out.println("</div>");

        // Bootstrap JS & Font Awesome
        out.println("<script src='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js'></script>");
        out.println("<link href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css' rel='stylesheet'>");

        out.println("</body>");
        out.println("</html>");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String idParam = request.getParameter("id");
        if (idParam == null || idParam.isEmpty()) {
            response.getWriter().println("<h3>No ID provided to delete.</h3>");
            return;
        }

        int id = Integer.parseInt(idParam);

        try (Connection con = DBConnection.con();
             PreparedStatement ps = con.prepareStatement("DELETE FROM crud_tbl WHERE id = ?")) {

            ps.setInt(1, id);
            int deleted = ps.executeUpdate();

            if (deleted > 0) {
                response.sendRedirect("ViewServlet");
            } else {
                response.getWriter().println("<h3>Record not found or already deleted.</h3>");
            }

        } catch (SQLException e) {
            response.getWriter().println("<h3>Database Error: " + e.getMessage() + "</h3>");
        } catch (Exception e) {
            response.getWriter().println("<h3>Unexpected Error: " + e.getMessage() + "</h3>");
        }
    }

    @Override
    public String getServletInfo() {
        return "Deletes a student record with stylish confirmation";
    }
}
