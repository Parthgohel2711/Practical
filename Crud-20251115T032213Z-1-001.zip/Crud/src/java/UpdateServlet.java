/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author DELL
 */
@WebServlet("/UpdateServlet")
public class UpdateServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        // ✅ Get ID from URL
        String idParam = request.getParameter("id");
        if (idParam == null || idParam.isEmpty()) {
            out.println("<h3>No ID provided in URL!</h3>");
            return;
        }

        int id = Integer.parseInt(idParam);

        out.println("<!DOCTYPE html>");
        out.println("<html lang='en'>");
        out.println("<head>");
        out.println("<meta charset='UTF-8'>");
        out.println("<meta name='viewport' content='width=device-width, initial-scale=1'>");
        out.println("<title>Edit Student Record</title>");

        // Bootstrap 5 CSS
        out.println("<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css' rel='stylesheet'>");

        // Font Awesome
        out.println("<link href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css' rel='stylesheet'>");

        // Custom CSS
        out.println("<style>");
        out.println("body { background-color: #f8f9fa; }");
        out.println(".container { margin-top: 60px; max-width: 600px; }");
        out.println(".card { border-radius: 10px; }");
        out.println("</style>");

        out.println("</head>");
        out.println("<body>");
        out.println("<div class='container'>");
        out.println("<div class='d-flex justify-content-between align-items-center mb-4'>");
        out.println("<h2 class='mb-0'>Edit Student</h2>");
        out.println("<a href='ViewServlet' class='btn btn-primary'><i class='fa-solid fa-eye me-1'></i>View Records</a>");
        out.println("</div>");

        try (Connection con = DBConnection.con();
             PreparedStatement ps = con.prepareStatement("SELECT * FROM crud_tbl WHERE id = ?")) {

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                String name = rs.getString("username");
                String email = rs.getString("email");
                String course = rs.getString("course");
                String password = rs.getString("password");

                // ✅ Edit Form
                out.println("<div class='card shadow-sm p-4'>");
                out.println("<form action='UpdateServlet' method='post'>");

                out.println("<input type='hidden' name='id' value='" + id + "'>");

                out.println("<div class='mb-3'>");
                out.println("<label class='form-label'>Name</label>");
                out.println("<input type='text' name='username' class='form-control' value='" + name + "' required>");
                out.println("</div>");

                out.println("<div class='mb-3'>");
                out.println("<label class='form-label'>Email</label>");
                out.println("<input type='email' name='email' class='form-control' value='" + email + "' required>");
                out.println("</div>");

                out.println("<div class='mb-3'>");
                out.println("<label class='form-label'>Course</label>");
                out.println("<select class='form-select' name='course' required>");
                out.println("<option value='' disabled>Select Course</option>");

                // Pre-select current course
                String[] courses = {"BCA", "BSc(IT)", "BCom", "BBA"};
                for (String c : courses) {
                    if (c.equalsIgnoreCase(course)) {
                        out.println("<option selected>" + c + "</option>");
                    } else {
                        out.println("<option>" + c + "</option>");
                    }
                }
                out.println("</select>");
                out.println("</div>");


                out.println("<div class='mb-3'>");
                out.println("<label class='form-label'>Password</label>");
                out.println("<input type='text' name='password' class='form-control' value='" + password + "' required>");
                out.println("</div>");

                out.println("<div class='text-center'>");
                out.println("<button type='submit' class='btn btn-success px-4 me-2'><i class='fa-solid fa-check me-1'></i>Update</button>");
                out.println("<a href='ViewServlet' class='btn btn-secondary px-4'>Cancel</a>");
                out.println("</div>");

                out.println("</form>");
                out.println("</div>");
            } else {
                out.println("<div class='alert alert-warning'>No record found for ID: " + id + "</div>");
            }

        } catch (SQLException e) {
            out.println("<div class='alert alert-danger mt-3'>Database Error: " + e.getMessage() + "</div>");
        } catch (Exception e) {
            out.println("<div class='alert alert-danger mt-3'>Unexpected Error: " + e.getMessage() + "</div>");
        }

        out.println("</div>");
        out.println("<script src='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js'></script>");
        out.println("</body>");
        out.println("</html>");
    }

    // ✅ Handle form submission (update data)
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        int id = Integer.parseInt(request.getParameter("id"));
        String username = request.getParameter("username");
        String email = request.getParameter("email");
        String course = request.getParameter("course");
        String password = request.getParameter("password");

        try (Connection con = DBConnection.con();
             PreparedStatement ps = con.prepareStatement(
                     "UPDATE crud_tbl SET username=?, email=?, course=?, password=? WHERE id=?")) {

            ps.setString(1, username);
            ps.setString(2, email);
            ps.setString(3, course);
            ps.setString(4, password);
            ps.setInt(5, id);

            int updated = ps.executeUpdate();

            if (updated > 0) {
                // ✅ Redirect to view page
                response.sendRedirect("ViewServlet");
            } else {
                out.println("<div class='alert alert-warning mt-3'>Failed to update record.</div>");
            }

        } catch (SQLException e) {
            out.println("<div class='alert alert-danger mt-3'>Database Error: " + e.getMessage() + "</div>");
        } catch (ClassNotFoundException ex) {
            System.getLogger(UpdateServlet.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        }
    }

    @Override
    public String getServletInfo() {
        return "Updates student record";
    }
}
