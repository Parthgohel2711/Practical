/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;

/**
 *
 * @author DELL
 */
@WebServlet("/ViewServlet")
public class ViewServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        out.println("<!DOCTYPE html>");
        out.println("<html lang='en'>");
        out.println("<head>");
        out.println("<meta charset='UTF-8'>");
        out.println("<meta name='viewport' content='width=device-width, initial-scale=1'>");
        out.println("<title>Student Records</title>");

        // Bootstrap 5 CSS
        out.println("<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css' rel='stylesheet'>");

        // Font Awesome
        out.println("<link href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css' rel='stylesheet'>");

        // Custom CSS
        out.println("<style>");
        out.println("body { background-color: #f8f9fa; }");
        out.println(".container { margin-top: 60px; }");
        out.println("table { background-color: #fff; border-radius: 8px; overflow: hidden; }");
        out.println("thead { background-color: #0d6efd; color: white; }");
        out.println("tbody tr { background-color: #ffffff !important; }"); // all rows same color
        out.println("td, th { vertical-align: middle !important; }");
        out.println(".btn-sm { border-radius: 20px; }");
        out.println("</style>");

        out.println("</head>");
        out.println("<body>");
        out.println("<div class='container'>");
        out.println("<div class='d-flex justify-content-between align-items-center mb-4'>");
        out.println("<h2 class='mb-0'><i class='fa-solid fa-user-graduate me-2'></i>Student Records</h2>");
        out.println("<a href='index.html' class='btn btn-primary '><i class='fa-solid fa-add me-1'></i>Add Student</a>");
        out.println("</div>");

        try (Connection con = DBConnection.con();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM crud_tbl")) {

            out.println("<div class='table-responsive shadow-sm'>");
            out.println("<table class='table table-bordered align-middle text-center'>"); // removed hover, striped
            out.println("<thead>");
            out.println("<tr>");
            out.println("<th>ID</th>");
            out.println("<th>Name</th>");
            out.println("<th>Email</th>");
            out.println("<th>Course</th>");
            out.println("<th>Password</th>");
            out.println("<th>Actions</th>");
            out.println("</tr>");
            out.println("</thead>");
            out.println("<tbody>");

            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("username");
                String email = rs.getString("email");
                String course = rs.getString("course");
                String password = rs.getString("password");

                out.println("<tr>");
                out.println("<td>" + id + "</td>");
                out.println("<td>" + name + "</td>");
                out.println("<td>" + email + "</td>");
                out.println("<td>" + course + "</td>");
                out.println("<td>" + password + "</td>");
                out.println("<td>");
                out.println("<a href='UpdateServlet?id=" + id + "' class='btn btn-warning'><i class='fa-solid fa-pen me-2'></i>Edit</a>");
                out.println("<a href='DeleteServlet?id=" + id + "' class='btn  btn-danger'><i class='fa-solid fa-trash me-2'></i>Delete</a>");
                out.println("</td>");
                out.println("</tr>");
            }

            out.println("</tbody>");
            out.println("</table>");
            out.println("</div>");

        } catch (SQLException e) {
            out.println("<div class='alert alert-danger mt-3'>Database Error: " + e.getMessage() + "</div>");
        } catch (Exception e) {
            out.println("<div class='alert alert-danger mt-3'>Unexpected Error: " + e.getMessage() + "</div>");
        }

        out.println("</div>");

        // Bootstrap JS
        out.println("<script src='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js'></script>");
        out.println("</body>");
        out.println("</html>");
    }

    @Override
    public String getServletInfo() {
        return "Displays student records from database";
    }
}
