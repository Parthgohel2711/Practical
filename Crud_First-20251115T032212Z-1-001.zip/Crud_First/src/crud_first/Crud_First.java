/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package crud_first;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.Scanner;

/**
 *
 * @author DELL
 */
public class Crud_First {
    /**
     * @return 
     * @throws java.lang.ClassNotFoundException
     * @throws java.sql.SQLException
     */
    
    public static Connection con() throws ClassNotFoundException, SQLException
    {
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/crud_first_db","root","");
    }
    
    public static void Insert() throws ClassNotFoundException, SQLException
    {
        Connection con = con();
        
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter name: ");
        String name = sc.nextLine();

        System.out.print("Enter age: ");
        String Age = sc.nextLine();

        System.out.print("Enter password: ");
        String password = sc.next();
        
        String unm = name;
        String age = Age;
        String Password = password;
        
        String Sql = "insert into crud_first_tbl (name,age,password) values(?,?,?)";
        PreparedStatement pst = con.prepareStatement(Sql);
        pst.setString(1,unm);
        pst.setString(2,age);
        pst.setString(3,Password);
        
        int rows = pst.executeUpdate();
        if(rows > 0)
        {
            System.out.print("Inserted Successful!");
        }
        else
        {
            System.out.println("Invalid Error!");
        }
    }
    
    public static void View() throws ClassNotFoundException, SQLException {
        try (Connection con = con()) {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM crud_first_tbl");
            
            System.out.println("----------------------------------------------------------");
            System.out.println("ID\tName\t\tAge\t\tPassword");
            System.out.println("----------------------------------------------------------");
            
            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                String age = rs.getString("age");
                String password = rs.getString("password");
                System.out.println(id + "\t" + name + "\t\t" + age + "\t\t" + password);
            }
            
            System.out.println("----------------------------------------------------------");
        }
    }

    public static void Update() throws ClassNotFoundException, SQLException {
        try (Connection con = con()) {
            Scanner sc = new Scanner(System.in);
            
            System.out.print("Enter ID: ");
            int id = sc.nextInt();
            sc.nextLine();
            
            System.out.print("Enter new name: ");
            String name = sc.nextLine();
            
            System.out.print("Enter new age: ");
            String age = sc.nextLine();
            
            System.out.print("Enter new password: ");
            String password = sc.nextLine();
            
            String sql = "UPDATE crud_first_tbl SET name = ?, age = ?, password = ? WHERE id = ?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, name);
            pst.setString(2, age);
            pst.setString(3, password);
            pst.setInt(4, id);
            
            int rows = pst.executeUpdate();
            if (rows > 0) {
                System.out.println("Record updated successfully!");
            } else {
                System.out.println("No record found for ID " + id);
            }
        }
    }

    public static void Delete() throws ClassNotFoundException, SQLException {
        try (Connection con = con()) {
            Scanner sc = new Scanner(System.in);
            
            System.out.print("Enter ID to delete: ");
            int id = sc.nextInt();
            sc.nextLine();
            
            System.out.print("Are you sure you want to delete this record? (yes/no): ");
            String value = sc.nextLine();
            
            if (value.equalsIgnoreCase("yes")) {
                String sql = "DELETE FROM crud_first_tbl WHERE id = ?";
                PreparedStatement pst = con.prepareStatement(sql);
                pst.setInt(1, id);
                
                int rows = pst.executeUpdate();
                if (rows > 0) {
                    System.out.println("Record deleted successfully!");
                } else {
                    System.out.println("No record found with ID " + id);
                }
            } else if (value.equalsIgnoreCase("no")) {
                System.out.println("Deletion cancelled.");
            } else {
                System.out.println("Invalid input. Please type 'yes' or 'no'.");
            }
        }
    }

    
    
    public static void main(String[] args) throws ClassNotFoundException, SQLException {
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n===== CRUD MENU =====");
            System.out.println("1. Insert Record");
            System.out.println("2. View Records");
            System.out.println("3. Update Record");
            System.out.println("4. Delete Record");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            int choice = sc.nextInt();

            try {
                switch (choice) {
                    case 1 -> Insert();
                    case 2 -> View();
                    case 3 -> Update();
                    case 4 -> Delete();
                    case 5 -> {
                        System.out.println("Exiting... Goodbye!");
                        sc.close();
                        return;
                    }
                    default -> System.out.println("Invalid choice! Try again.");
                }
            } catch (ClassNotFoundException | SQLException e) {
            }
        }
    }
}
    
